# Tests for label-studio-sso
