"""
Pytest configuration for label-studio-sso tests

Note: jwt_secret fixture removed in v6.0.0
Method 1 (External JWT) has been removed
All tests now use Label Studio's SECRET_KEY directly
"""
